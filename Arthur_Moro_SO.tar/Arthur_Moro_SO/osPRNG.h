/*
        osPRNG() - A pseudorandom library call
*/

#ifndef __OSPRNG_H__
#define __OSPRNG_H__

#include <stdio.h>
#include <stdlib.h>

int osPRNG(void);

#endif
